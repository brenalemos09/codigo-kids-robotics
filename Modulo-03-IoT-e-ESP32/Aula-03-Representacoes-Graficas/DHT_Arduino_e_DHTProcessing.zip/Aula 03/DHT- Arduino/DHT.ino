#include <DHT.h>
#define DHTPIN 2
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  dht.comeco();
  Serial.begin(9600);
}

void loop() {
  float h = dht.le_umidade();
  float t = dht.ler_Temperatura();

  if (isnan(t) || isnan(h)) {
    Serial.print("NO DATA");
  } else {
      Serial.println(String(h)+";"+String(t));
  }
  delay(2000);
}
