import processing.serial.*;

Serial myPort;
String val;
int lf=10;

float humidity, temperature;
float axis[] = new float[2];

FloatList huPoints;
FloatList tePoints;
FloatList xPoints;

float xIni = 65;
boolean aux=false;

PImage bg;
PFont verdana;

void settings() {
  size(800, 500);
}

void setup() {
  String portName = Serial.list()[1];
  printArray(Serial.list());
  myPort = new Serial(this, portName, 9600);
  myPort.bufferUntil(lf);
  bg = loadImage("Back.png");
  huPoints = new FloatList();
  tePoints = new FloatList();
  xPoints = new FloatList();
  verdana = createFont("Verdana Negrito", 48);
  textFont(verdana);
}

void serialEvent(Serial p) {
  val = p.readString();
  int spacer = val.indexOf(';');
  String _hu = val.substring(0, spacer);
  String _te = val.substring(spacer+1, val.length());
  humidity = Float.valueOf(_hu);
  temperature = Float.valueOf(_te);
}

void convValues() {
  boolean testH = humidity <= 100 && humidity >= 0; 
  boolean testT = temperature <= 50 && temperature >= 0;
  if (testH && testT) {
    axis[0] = map(humidity, 0, 100, 480, 130);
    axis[1] = map(temperature, 0, 50, 480, 130);
    println(axis[0]);
    println(axis[1]);
    if(axis[0]!=480 && axis[1]!=480){
      //xPoints.append(xIni);
      huPoints.append(axis[0]);
      tePoints.append(axis[1]);
      aux=true;
      if(xIni>730){
        //xIni=65;
        huPoints.remove(0);
        tePoints.remove(0);
        //xPoints.clear();
      }
      else{
        xPoints.append(xIni);
        xIni+=0.2;
      }
    }    
  }
}

void draw() {
  image(bg, 0, 0);
  convValues();
  //noStroke();
  strokeWeight(2);
  if (aux && huPoints.size()>1) {
    int j = huPoints.size()-1;
    print("j: "+j);
    for(int i=0; i < j;i++){
      stroke(0,0,255);
      line(xPoints.get(i),huPoints.get(i),xPoints.get(i+1),huPoints.get(i+1));
      stroke(255,0,0);
      line(xPoints.get(i),tePoints.get(i),xPoints.get(i+1),tePoints.get(i+1));
    }
    fill(255);
    textSize(48);
    text(int(temperature) + "°",665,70);
    textSize(12);
    text(day()+"/"+month()+"/"+year(),665,90);
    text(int(humidity) + "%",760,75);
  }
}
