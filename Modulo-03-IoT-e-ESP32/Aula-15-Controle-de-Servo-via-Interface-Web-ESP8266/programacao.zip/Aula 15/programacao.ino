#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Servo.h>


Servo meuServo;

 char ssid[] = "Grupo Maker";
 char password[] = "!@#maker456";

WiFiServer server(80);
String header;

String valueString = String(5);
int pos1 = 0;
int pos2 = 0;

unsigned long currentTime = millis();

unsigned long previousTime = 0; 

const long timeoutTime = 2000;

void setup() {

  Serial.begin(115200);
  meuServo.attach(5);

  Serial.print("Connecting to ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  server.begin();
}

void loop() {

  WiFiClient client = server.available();   

  if (client) {                     
    currentTime = millis();
    previousTime = currentTime;
    Serial.println("New Client.");          
    String currentLine = "";  
    while (client.connected() && currentTime - previousTime <= timeoutTime) { 
      currentTime = millis();
      if (client.available()) {        
        char c = client.read();           
        Serial.write(c);             
        header += c;
        if (c == '\n') {  

          if (currentLine.length() == 0) {
           
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println("Connection: close");
            client.println();

       
            client.println("<!DOCTYPE html><html>");
            client.println("<head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            client.println("<meta charset=\"UTF-8\">");
            client.println("<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">");
            client.println("<title>Servomotor</title>");

            client.println("<style> * {  margin: 0; padding: 0; font-family: ""Poppins"", sans-serif;}");
            client.println("body { display: flex; justify-content: center; align-items: center;  min-height: 100vh; background: #151515;}");
            client.println("#servoPos { position: relative; display: block; text-align: center; font-size: 6em; color: #999; font-weight: 400;}");
            client.println(".range{ width: 400px; height: 15px; -webkit-appearance: none; background: #111; outline: none; border-radius: 15px; overflow: hidden; box-shadow: inset 0 0 5px rgba(0, 0, 0, 1);}");
            client.println("<p>Position: <span id=\"servoPos\"></span></p>");
            client.println(".range::-webkit-slider-thumb { -webkit-appearance: none; width: 15px; height: 15px; border-radius: 50%; background: #00fd0a; cursor: pointer;  border: 4px solid #333; box-shadow: -407px 0 0 400px #00fd0a;}");
   
            client.println("</style>");
            client.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
                     
            client.println("<span id=\"servoPos\"></span>");
            client.println(" <Input class=\"range\" type=\"range\" name "" value=\"0\" min=\"0\" max=\"180\" id=\"servoSlider\" onChange=\"servo(this.value)\" value=\""+valueString+"\"/>"); 
    
            client.println("<script>var slider = document.getElementById(\"servoSlider\");");
            client.println("var servoP = document.getElementById(\"servoPos\"); servoP.innerHTML = slider.value;");
            client.println("slider.oninput = function() { slider.value = this.value; servoP.innerHTML = this.value; }");
            client.println("$.ajaxSetup({timeout:1000}); function servo(pos) { ");
            client.println("$.get(\"/?value=\" + pos + \"&\"); {Connection: close};}</script>");
           
            client.println("</body></html>");     
            
            if(header.indexOf("GET /?value=")>=0) {
              pos1 = header.indexOf('=');
              pos2 = header.indexOf('&');
              valueString = header.substring(pos1+1, pos2);
              
              meuServo.write(valueString.toInt());
              Serial.println(valueString); 
            }         

            client.println();

            break;
          } else { 
            currentLine = "";
          }
        } else if (c != '\r') {  
          currentLine += c;      
        }
      }
    }

    header = "";

    client.stop();
    Serial.println("Client disconnected.");
    Serial.println("");
  }
}
