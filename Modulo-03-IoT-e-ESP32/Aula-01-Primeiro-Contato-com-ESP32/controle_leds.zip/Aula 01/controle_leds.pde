  import processing.serial.*;
  import cc.arduino.*;
  
/*--Vinculando o arduino à biblioteca--*/
  Arduino arduino;
  
/* -- Variáveis responsáveis pelo controle dos Leds --*/
  int ledAzul = 12;    
  int ledAmarelo = 11;  
  int ledVermelho = 10;
  
/*--Variáveis responsáveis pelas cores da interface-*/  
  int Azul = 125;
  int Amarelo = 150;
  int Vermelho = 150;
  
  void settings(){
     size(600,500); //Cria a tela de aplicação
     smooth(2); // especifica o anti-aliasing
  }
  
  void setup() {
    
    frameRate(60);  
    arduino = new Arduino(this, Arduino.list()[1], 57600);
 
    textSize(36);
    textAlign(CENTER);
    background(51);
    fill(255, 255, 255);
    text("Controlador de Led's", 300, 400);
    
  arduino.pinMode(ledAzul, Arduino.OUTPUT);
  arduino.pinMode(ledAmarelo, Arduino.OUTPUT);
  arduino.pinMode(ledVermelho, Arduino.OUTPUT);
  
  }
  
  void draw() {
//--------------Círculo Azul-------------------------//    
    fill(0,0,Azul);
    ellipse(100, 200, 180, 180);
    fill(255, 255, 255);
    textSize(24);
    textAlign(CENTER);
    text("Azul", 90, 95);
//--------------Círculo Amarelo-------------------------//    
    fill(0,Amarelo,0);
    ellipse(300, 200, 180, 180);
    fill(255, 255, 255);
    textSize(24);
    textAlign(CENTER);
    text("Amarelo", 300, 95);
//--------------Círculo Vermelho-------------------------//     
    fill(Vermelho,0,0);
    ellipse(500, 200, 180, 180);
    fill(255, 255, 255);
    textSize(24);
    textAlign(CENTER);
    text("Vermelho", 500, 95);
//---------------------------------------//  
 println(mouseX ,": ", mouseY);
  }
  
/*--Aqui conterá os códigos que ligarão e desligarão os leds e mudarão a cor das elipses--*/

  void mouseClicked() {
    
    // Botao Azul
    if (mouseX > 10 && mouseX < 190 && mouseY > 96 && mouseY < 288)
    {
      if (Azul == 125)
      {
        Azul = 255;
        arduino.digitalWrite(ledAzul, 1);
      } else {
        Azul = 125;
        arduino.digitalWrite(ledAzul, 0);
      }
    }
  
    // Botao amarelo
    if (mouseX > 210 && mouseX < 388 && mouseY > 109 && mouseY < 290)
    {
      if (Amarelo == 150)
      {
        Amarelo = 255;      
        arduino.digitalWrite(ledAmarelo, 1);
      }else{
        Amarelo = 150;
        arduino.digitalWrite(ledAmarelo, 0);
      }
    }
  
    // Botao vermelho
    if (mouseX > 409 && mouseX < 589 && mouseY > 110 && mouseY < 290)
    {
      if (Vermelho == 150)
      {
        Vermelho = 255;
        arduino.digitalWrite(ledVermelho, 1);
      }else
      {
        Vermelho = 150;
        arduino.digitalWrite(ledVermelho, 0);
      }
    }
  }
