# incluindo bibliotecas
import time           
import serial

# Iniciando conexao serial
comport = serial.Serial('com23', 9600) 

# inicio do loop
while True:
	# solicita um comando ao usuario
	key = input("command: ")
	
	# verifica se o comando foi 'led1'
	if key == 'w1':
		comport.write(b'1')

	# verifica se o comando foi 'led2'
	if key == 'w2':
		comport.write(b'2')

	# verifica se o comando foi 'q'
	if key == 'q':
		quit()

	


