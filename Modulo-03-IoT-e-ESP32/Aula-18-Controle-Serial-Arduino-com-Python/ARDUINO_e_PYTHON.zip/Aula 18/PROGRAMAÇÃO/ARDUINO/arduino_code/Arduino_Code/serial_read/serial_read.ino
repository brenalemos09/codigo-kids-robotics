#define led1 D4
#define led2 D3
#define bot1 D2
#define bot2 D1

bool led1Estate = 0;
bool led2Estate = 0;
bool bot1Read = 0;
bool bot2Read = 0;

char serialRead;

void setup() {
  Serial.begin(9600);
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(bot1, INPUT_PULLUP);
  pinMode(bot2, INPUT_PULLUP);
}

void loop() {

  bool bot1Read = digitalRead(bot1);
  bool bot2Read = digitalRead(bot2);

  if (Serial.available() > 0){
    serialRead = Serial.read();
  }

  if(bot1Read == 0 || serialRead == '1'){
    led1Estate = !led1Estate;
    serialRead = 0;
  }
  if(bot2Read == 0 || serialRead == '2'){
    led2Estate = !led2Estate;
    serialRead = 0;
  }
  
  digitalWrite(led1, led1Estate);
  digitalWrite(led2, led2Estate);
  delay(200);
}
