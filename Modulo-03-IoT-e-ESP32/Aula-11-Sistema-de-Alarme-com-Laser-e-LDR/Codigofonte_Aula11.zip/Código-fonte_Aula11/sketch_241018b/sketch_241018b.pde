import processing.serial.*;

Serial myPort;
int Anim, ImgVeri, i = 0;
int Veri, Adc = 1;
int x, y;
String inString;
PImage alarm1, alarm2, alarm0;

void serialEvent(Serial p) {
  inString = p.readString();
}

void setup() {

  printArray(Serial.list());
  myPort = new Serial(this, Serial.list()[0], 115200);
  myPort.bufferUntil('\n');

  size(300, 400, P2D);
  textSize(30);
  textAlign(CENTER, CENTER);

  alarm1 = loadImage("Alarm(3).png");
  alarm2 = loadImage("Alarm(2).png");
  alarm0 = loadImage("Alarm(0).png");
}

void draw() {

  x = 85;
  y = 60;

  background(60, 60, 80);

  stroke(0);
  strokeWeight(2);
  fill(235, 220, 195);
  rect(25, 25, 250, 350, 10);

  if (i > 100) {
    if (keyPressed == true) {
      if (key == ' ' && Veri == 0) {

        myPort.write('0');
        Veri = 1;
        delay(500);
      } else if (key == ' ' && Veri == 1) {

        myPort.write('1');
        Veri = 0;
        delay(500);
      }
    }

    if (Veri == 0) {

      println(inString);
      float ldr = 0;
      ldr = float(inString);

      if (ldr > 80) {

        fill(0);
        text("LOCKED", 150, 270);
        fill(35, 174, 81);

        rect(40, 320, Anim, 30, 10);
        rect(260 - Anim, 320, Anim, 30, 10);

        image(alarm2, x, y, 130, 130);

        Anim += Adc;
        if (Anim >= 225 / 2) Adc = -1;
        else if (Anim <= 0) Adc = 1;
      } else {

        fill(0);
        text("OPENED", 150, 270);
        fill(255, 0, 0);

        if (ImgVeri == 1) {
          image(alarm2, x, y, 130, 130);
          ImgVeri = 0;
        } else {
          image(alarm1, x, y, 130, 130);
          ImgVeri = 1;
        }
        delay(200);

        rect(40, 320, 225, 30, 10);
      }
    } else {

      fill(0);

      text("ALARM", 155, 270);
      text("DISABLED", 155, 300);

      image(alarm0, x, y, 130, 130);
    }
  } else {
    i++;
  }
}
