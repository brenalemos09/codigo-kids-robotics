int laser = D5;
int ldr = A0;

void setup() {
  Serial.begin(115200);

  pinMode(laser, OUTPUT);
  pinMode(ldr, INPUT);
  digitalWrite(D5, HIGH);
}

void loop() {
  int Value = analogRead(ldr);
  Serial.println(Value);
  delay(100);


  if (Serial.available() > 0) {
    // Lê o dado enviado pelo Processing
    char comando = Serial.read();

    // Se receber '1', acende o LED
    if (comando == '1') {
      digitalWrite(D5, HIGH);
    }
    // Se receber '0', apaga o LED
    else if (comando == '0') {
      digitalWrite(D5, LOW);
    }
  }

}
