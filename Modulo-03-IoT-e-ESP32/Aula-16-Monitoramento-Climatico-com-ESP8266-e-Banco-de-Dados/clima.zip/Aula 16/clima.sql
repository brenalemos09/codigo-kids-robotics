-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 28-Out-2021 às 15:00
-- Versão do servidor: 10.4.18-MariaDB
-- versão do PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `meteorologia`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clima`
--

CREATE TABLE `clima` (
  `id` int(11) NOT NULL,
  `temperatura` float NOT NULL,
  `umidade` float NOT NULL,
  `data_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clima`
--

INSERT INTO `clima` (`id`, `temperatura`, `umidade`, `data_time`) VALUES
(1, 24.2, 62, '2021-10-27 16:41:34'),
(2, 24.2, 62, '2021-10-27 16:41:42'),
(3, 24.2, 62, '2021-10-27 16:41:50'),
(4, 24.2, 62, '2021-10-27 16:41:58'),
(5, 24.2, 61, '2021-10-27 16:42:06'),
(6, 24.3, 52, '2021-10-27 17:18:20'),
(7, 24.4, 52, '2021-10-27 17:18:28'),
(8, 24.5, 50, '2021-10-27 17:43:17'),
(9, 24.3, 49, '2021-10-27 17:43:25'),
(10, 0, 0, '2021-10-27 17:45:59');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clima`
--
ALTER TABLE `clima`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clima`
--
ALTER TABLE `clima`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
