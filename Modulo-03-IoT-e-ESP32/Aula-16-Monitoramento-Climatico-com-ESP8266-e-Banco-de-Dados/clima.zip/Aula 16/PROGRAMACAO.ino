  #include <DHT.h>
  #include <ESP8266WiFi.h>

  
  #define DHTPIN 14
  #define DHTTYPE DHT11
  DHT dht (DHTPIN, DHTTYPE);
  
  const char* ssid = "Grupo Maker";
  const char* password = "!@#maker456";
  const char* host = "192.168.0.100";
  
  void setup() {
    
    Serial.begin(115200);
    Serial.println("DHT11 Output!");
    dht.begin();
  
    Serial.println();
    Serial.println();
    Serial.println("Connecting to ");
    Serial.println(ssid);
  
     WiFi.begin(ssid, password);
  
     while (WiFi.status() != WL_CONNECTED){
        delay(500);
        Serial.print(".");
     }
  
     Serial.println();
     Serial.println("Wifi conectado");
     Serial.println("IP address: ");
     Serial.println(WiFi.localIP());
     
  }
  
  void loop() {
  
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
  
    if(isnan(temperature) || isnan(humidity)){
      Serial.println("Falha na leitura do sensor");
    }else{
      Serial.print("Humidity: ");
      Serial.print(humidity);
      Serial.print("%\t");
      Serial.print("Temperature: ");
      Serial.print(temperature);
      Serial.print(" *C");
      delay(3000);
    }
  
    Serial.print("Connecting to ");
    Serial.print(host);
  
    WiFiClient client;
    const int httpPort = 80;
    if(!client.connect(host, httpPort)){
      Serial.println("Falha na Conexão");
      return;
    }
  
    client.print(String("GET http://localhost//EVOLUA/clima.php?") +
                              ("&temperatura=") + temperature +
                              ("&umidade=") + humidity +
                              " HTTP/1.1\r\n" +
                      "Host: " + host + "\r\n" +
                      "Connection: close\r\n\r\n");
       unsigned long timeout = millis();
       while (client.available() == 0){
        if (millis() - timeout > 1000){
          Serial.println(">>> Client Timeout !");
          client.stop();
          return;
        }
       }
  
       while(client.available()){
        String line = client.readStringUntil('\n');
        Serial.print(line);
       }
  
       Serial.println();
       Serial.println("Closing connection");
  }
