<html>
<body>
    <?php

        $dbname = 'meteorologia';
        $dbuser = 'AULA';
        $dbpass = 'root123#';
        $dbhost = 'localhost';

        $connect = @mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

        if(!$connect){
            echo "ERROR: " . mysqli_connect_error();
            exit();
        }

        echo "Sucesso na conexão!<br><br>";

        $temperatura = $_GET["temperatura"];
        $umidade = $_GET["umidade"];

        $query = "INSERT INTO clima (temperatura, umidade) VALUES ('$temperatura', '$umidade')";
        $result = mysqli_query($connect,$query);

        echo "Inserido com Sucesso!<br>";
    ?>
</body>
</html>