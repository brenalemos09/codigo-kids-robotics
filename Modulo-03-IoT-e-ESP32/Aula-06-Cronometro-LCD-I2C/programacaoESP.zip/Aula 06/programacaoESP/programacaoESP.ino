#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

int temp= 100;
 
void setup() {
lcd.init();
lcd.backlight();
 
for (int i = 0; i <= t; i++) {
  lcd.clear();
  lcd.print("Cronometro");
  lcd.setCursor(0, 1);
  lcd.print("Tempo: ");
  lcd.setCursor(7, 1);
  lcd.print(i);
delay(1000);
}
   
  lcd.clear();
  lcd.print("Fim!");
 
}
 
void loop() {}
