int pencil_size = 10;
float colors[] = {0, 0, 0};
float transparency=100;
String menu[] = {"Transp.","  Red", "Green","  Blue"," New","  Pencil"};
int radius=12;
PVector v;
float posicion[]={35, 85, 135, 185, 235};

void settings() {
  size(400, 600);
  smooth(2);
}

void setup() {
  surface.setTitle("Pictorem");
  frameRate(60);
  background(255);
  fill(#0C0C26);
  noStroke();
  rect(0, 550, 400, 50);
  int j=0;
  for (int i=15; i<270; i+=50) {
    fill(255);
    text(menu[j], i, 565);
    j++;
  }
  j=0;
  for (float i=35; i<190; i+=50) {
    posicion[j]=i;
    fill(#D8D8D8);
    noStroke();
    ellipseMode(CENTER);
    ellipse(i, 585, radius*2, radius*2);
    textSize(11);
    fill(#0C0C26);
    text("+/-", i-9, 588);
    j++;
  }
  fill(#8B070B);
  ellipse(235, 585, radius*2, radius*2);
}

void menu(float e){
  int i;
  for(i=0; i<4;i++){
    v = new PVector(mouseX-posicion[i], mouseY-585);
    float len = v.mag();
    if (len < radius){
      break;
    }
  }
  switch (i){
    case 0:
    float t = (e>0 && transparency<100) ? transparency+=5 : transparency--; 
    println("transparency: "+transparency);
    break;
    case 1:
    t = (e>0 && colors[0]<255) ? colors[0]+=5 : colors[0]--; 
    println("Red: "+colors[0]);
    break;
    case 2:
    t = (e>0 && colors[1]<255) ? colors[1]+=5 : colors[1]--; 
    println("Green: "+colors[1]);
    break;
    case 3:
    t = (e>0 && colors[2]<255) ? colors[2]+=5 : colors[2]--; 
    println("Blue: "+colors[2]);
    break;
  }

}

void mouseWheel(MouseEvent event) {
  float e = event.getCount();
  if (mouseY < 550) {
    if (e > 0 && pencil_size < 100) {
      pencil_size++;
    }
    if (e < 0 && pencil_size > 1) {
      pencil_size--;
    }
  }
  else{
    menu(e);
  }
}

void mouseDragged() {
  boolean test = (mouseY + pencil_size/2) > 550;
  if (!test) {
    fill(colors[0],colors[1], colors[2],transparency);
    noStroke();
    rect(mouseX-(pencil_size/2), mouseY-(pencil_size/2), pencil_size, pencil_size);
  }
}

void mousePressed(){
  if(mouseY + pencil_size/2 > 550){
  v = new PVector(mouseX-posicion[4], mouseY-585);
    float len = v.mag();
    if (len < radius){
      background(255);
      setup();
    }
  }
  else{
    fill(colors[0],colors[1], colors[2],transparency);
    noStroke();
    rect(mouseX-(pencil_size/2), mouseY-(pencil_size/2), pencil_size, pencil_size);
  }
}
void draw() {
  noStroke();
  fill(#0C0C26);
  rect(270, 570, 50, 20);
  fill(255);
  textSize(11);
  text(pencil_size, 285, 585);
  stroke(255);
  strokeWeight(2);
  fill(colors[0],colors[1], colors[2],transparency);
  ellipse(360, 575, 30, 30);
}
