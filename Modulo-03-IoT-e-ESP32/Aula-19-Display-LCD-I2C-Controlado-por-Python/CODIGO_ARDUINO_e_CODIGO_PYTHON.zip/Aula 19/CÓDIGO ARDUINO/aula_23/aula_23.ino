 #include <Wire.h> 
 #include <LiquidCrystal_I2C.h>

 LiquidCrystal_I2C lcd(0x27, 16, 2);  

 String serialRead;

 void setup(){
  Serial.begin(9600);
  Wire.begin(D2, D1);
  lcd.backlight();
  lcd.home();
  lcd.clear();
 }


 void loop(){
  if (Serial.available() > 0){
     lcd.clear();
     serialRead = Serial.readString();
     lcd.clear();
     lcd.setCursor(0,0);
     lcd.print(serialRead);
    }
 }

  
