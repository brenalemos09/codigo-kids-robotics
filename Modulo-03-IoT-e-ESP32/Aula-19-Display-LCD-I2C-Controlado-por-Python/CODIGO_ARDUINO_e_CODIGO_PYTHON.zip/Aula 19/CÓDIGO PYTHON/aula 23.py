import serial
import time

arduino = serial.Serial('com23', 9600)

arduino.write(b'Bem Vindo!!')

while True:

    palavra = str(input('digite uma palavra: '))
    arduino.write(str.encode(palavra))

    modificacao = (input('''
    [1] Len
    [2] Upper
    [3] Lower
    [4] Fatiar
    [5] Replace
    [6] Quit

    Escolha a modificação desejada:  '''))

    time.sleep(1)

    if modificacao == '1':
        mod1 = str(len(palavra))
        arduino.write(str.encode(mod1))

    if modificacao == '2':
        arduino.write(str.encode(palavra.upper()))  
    
    if modificacao == '3':
        arduino.write(str.encode(palavra.lower()))   

    if modificacao == '4':
        n1 = int(input('digite um valor para começar o fatiamento'))
        n2 = int(input('digite um valor para encerrar o fatiamento'))
        n3 = palavra[n1:n2]
        arduino.write(str.encode(n3))    

    if modificacao == '5':
        p1 = input('Qual palavra deseja substituir? ')
        p2 = input('Qual palavra irá substitui-la? ')
        r = (palavra.replace(p1, p2))
        arduino.write(str.encode(r))

    if modificacao == '6':
        arduino.write(b'Encerrado')
        time.sleep(1)
        quit()