// importando biblioteca serial.
import processing.serial.*;
// importando biblioteca arduino.
import cc.arduino.*;

// vinculando o arduino à biblioteca.
Arduino arduino;
Serial myPort;

// portas PWM em que o led RGB está conectado.
int ledR = 9;    
int ledG = 10;  
int ledB = 11;  

// armazena o valor atual de cada cor.
int red;           
int green;         
int blue;          

void settings() {
  size(600, 300);  // cria a tela da aplicação.
  smooth(2);       // especifica o antialise.
}

void setup() {
  // especifica o título da janela
  surface.setTitle("RGB Controller");
  // determina a taxa de atualização.
  frameRate(60);   
  
  // vincula o arduino ao Processing, atraves da USB.
  arduino = new Arduino(this, Arduino.list()[0], 57600);
  
  // configura todas as portas como Saida.
  arduino.pinMode(ledR, Arduino.OUTPUT);
  arduino.pinMode(ledG, Arduino.OUTPUT);
  arduino.pinMode(ledB, Arduino.OUTPUT);
}

void draw() {
  background(230);//51
  
  noStroke();
  
  textSize(28);
  textAlign(CENTER);
  fill(0);//(255, 255, 255);
  text("RGB Controller Interface", 300, 60);
  
  // cria a letra 'R'.
  textSize(32);
  fill(0);
  text("R", 55, 135);
  
  // cria o cursor e a barra vermelha.
  fill(255, 0, 0);
  rect(100, 120, 255, 10, 5);
  fill(0);
  rect(red + 100, 115, 10, 20, 8);
  
  // cria a letra 'G'.
  textSize(32);
  fill(0);
  text("G", 55, 200);
  
  // cria o cursor e a barra verde.
  fill(0, 255, 0);
  rect(100, 185, 255, 10, 5);
  fill(0);
  rect(green + 100, 180, 10, 20, 8);
  
  // cria a letra 'B'.
  textSize(32);
  fill(0);
  text("B", 55, 265);
  
  // cria o cursor e a barra azul.
  fill(0, 0, 255);
  rect(100, 250, 255, 10, 5);
  fill(0);
  rect(blue + 100, 245, 10, 20, 8);
  
  // cria a elipse que exibe a cor atual.
  fill(red, green, blue);
  ellipse(480, 190, 130, 130);
  
  // detecta a posição da barra vermelha onde o mouse foi precionado.
  if (mousePressed && mouseX > 100 && mouseX < 355 && mouseY > 115 && mouseY < 145)
  {
     red = mouseX - 100;               // subtrai - 100 à posição do mouseX e atribui à variável red.
     arduino.analogWrite(ledR, red);   // utiliza a variável red como valor de PWM, acendendo o led.
  }
  
  // detecta a posição da barra verde onde o mouse foi precionado.
  else if (mousePressed && mouseX > 100 && mouseX < 355 && mouseY > 170 && mouseY < 210)
  {
     green = mouseX - 100;             // subtrai - 100 à posição do mouseX e atribui à variável green.
     arduino.analogWrite(ledG, green); // utiliza a variável red como valor de PWM, acendendo o led.
  }
  
  // detecta a posição da azul vermelha onde o mouse foi precionado.
  else if (mousePressed && mouseX > 100 && mouseX < 355 && mouseY > 235 && mouseY < 275)
  {
     blue = mouseX - 100;              // subtrai - 100 à posição do mouseX e atribui à variável blue.
     arduino.analogWrite(ledB, blue);  // utiliza a variável red como valor de PWM, acendendo o led.
  }
}
