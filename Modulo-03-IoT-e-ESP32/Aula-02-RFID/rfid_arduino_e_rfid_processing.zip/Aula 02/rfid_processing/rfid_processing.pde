import processing.serial.*; 
 
Serial myPort;    
String inString; 

PImage bg;
PImage blocked;
PImage open;

float arcX=200, arcY=350;
int arcControl=0;

int bgControl=2;

float animation;

void settings() {
  size(400, 520);
  
  smooth(2);
  
  printArray(Serial.list()); 
  
  myPort = new Serial(this, Serial.list()[1], 9600); 
  myPort.bufferUntil(10);
}

void setup() {
  bg = loadImage("Back.png");
  blocked = loadImage("Blocked.png");
  open = loadImage("Open.png");
}

void serialEvent(Serial p) { 
  inString = p.readString(); 
  
  float inSerial = float(inString);
  
  if(inSerial == 1){
    bgControl = 1;
    delay(5000);
    bgControl = 0;
    println("identificado!");
  }
  else if(inSerial == 2){
    bgControl = 2;
    delay(5000);
    bgControl = 0;
    println("não identificado!");
  }
  else{
    bgControl = 0;
  }
}

void draw() {
  switch(bgControl) {
  case 0:
    image(bg, 0, 0);
    break;
  case 1:
    image(open, 0, 0);
    break;
  case 2:
    image(blocked, 0, 0);
    break;
  }
  noFill();
  stroke(255-(animation*10), 100+(animation*10), animation*20);
  strokeWeight(10);

  if (bgControl==0) {
    if (animation > 3 && animation <= 6) {
      arc(arcX, arcY, 260, 260, radians(-15), radians(15));
      arc(arcX, arcY, 260, 260, radians(165), radians(195));
    } else if (animation > 6 && animation <= 9) {
      arc(arcX, arcY, 260, 260, radians(-15), radians(15));
      arc(arcX, arcY, 260, 260, radians(165), radians(195));
      arc(arcX, arcY, 310, 310, radians(-15), radians(15));
      arc(arcX, arcY, 310, 310, radians(165), radians(195));
    } else if (animation > 9 && animation <= 12) {
      arc(arcX, arcY, 260, 260, radians(-15), radians(15));
      arc(arcX, arcY, 260, 260, radians(165), radians(195));
      arc(arcX, arcY, 310, 310, radians(-15), radians(15));
      arc(arcX, arcY, 310, 310, radians(165), radians(195));
      arc(arcX, arcY, 360, 360, radians(-15), radians(15));
      arc(arcX, arcY, 360, 360, radians(165), radians(195));
    } else if (animation > 12) {
      animation=0;
    }
    animation+=0.1;
  }
}
