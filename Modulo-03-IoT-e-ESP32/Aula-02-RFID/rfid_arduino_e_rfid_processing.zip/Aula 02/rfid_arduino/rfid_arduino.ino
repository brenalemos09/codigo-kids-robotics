// --- Bibliotecas Auxiliares ---
#include <SPI.h>
#include <MFRC522.h>

// --- Mapeamento de Hardware ---
#define SS_PIN 10
#define RST_PIN 9
MFRC522 mfrc522(SS_PIN, RST_PIN);   
 
// --- Variáveis Globais --- 
char st[20];

// --- Configurações Iniciais ---
void setup() 
{
  Serial.begin(9600);   
  SPI.begin();          
  mfrc522.PCD_Init();   
  
  Serial.println("Aproxime o seu cartao do leitor...");
  Serial.println();
}

// --- Loop Infinito ---
void loop() 
{
  // Verifica novos cartões
  if ( ! mfrc522.PICC_IsNewCardPresent()) 
  {
    return;
  }
  // Seleciona um dos cartões
  if ( ! mfrc522.PICC_ReadCardSerial()) 
  {
    return;
  }
  
  String conteudo= "";
  byte letra;
  
  for (byte i = 0; i < mfrc522.uid.size; i++) 
  {
     Serial.print(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " ");
     Serial.print(mfrc522.uid.uidByte[i], HEX);
     conteudo.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " "));
     conteudo.concat(String(mfrc522.uid.uidByte[i], HEX));
  }
  Serial.println();
  conteudo.toUpperCase();
  
/*  if (conteudo.substring(1) == "86 BB C9 25") //Chaveiro
  {
    Serial.println(1);
    delay(1000);
  }
 
  if (conteudo.substring(1) == "B9 C1 1C C3") //Cartao
  {
    Serial.println(2);
    delay(1000); 
  }  */
}
 
 
