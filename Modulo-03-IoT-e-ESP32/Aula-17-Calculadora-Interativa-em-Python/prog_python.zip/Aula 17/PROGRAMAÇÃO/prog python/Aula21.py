import time



print('Bem Vindo a Calculadora Python!')
time.sleep(1)



operacao = 0
while operacao == 0:

    num1 = int(input('Escolha um numero para a operação: '))
    num2 = int(input('Escolha outro numero para a operação: '))

    operacao = int(input('''Qual será a operação desejada?
    [1] Adição
    [2] Subtração
    [3] Divisão
    [4] Multiplicação
    [5] Quit
    Qual será a operação desejada?
    '''))



    if operacao == 1:   
        print('A adição entre {} e {} é igual a {}'.format(num1, num2, num1 + num2))
        time.sleep(1)
        print('Vamos realizar outra operação:')
        time.sleep(1)
        operacao = 0

    if operacao == 2:
        print('A subtração entre {} e {} é igual a {}'.format(num1, num2, num1 - num2))
        time.sleep(1)
        print('Vamos realizar outra operação:')
        time.sleep(1)
        operacao = 0

    if operacao == 3:
        print('A divisão entre {} e {} é igual a {}'.format(num1, num2, num1 / num2))
        time.sleep(1)
        print('Vamos realizar outra operação:')
        time.sleep(1)
        operacao = 0

    if operacao == 4:
        print('A multiplicação entre {} e {} é igual a {}'.format(num1, num2, num1 * num2))
        time.sleep(1)
        print('Vamos realizar outra operação:')
        time.sleep(1)
        operacao = 0


    if operacao >= 5:
        print('Estamos finalizando a calculadora Python. Volte sempre!')
        time.sleep(1)
        quit()



