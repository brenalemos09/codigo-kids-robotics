int sensorRead;

void setup() {
  Serial.begin(9600);
}

void loop() {

  sensorRead = analogRead(A0) / 10;
  
  Serial.print(sensorRead);
  Serial.print("\n");
  delay(3);
}
