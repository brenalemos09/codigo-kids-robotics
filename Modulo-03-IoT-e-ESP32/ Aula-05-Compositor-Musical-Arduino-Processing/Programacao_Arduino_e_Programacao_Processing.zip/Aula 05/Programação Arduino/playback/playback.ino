#define falante 11

void setup() {
  Serial.begin(9600);
}
void loop() {
  if (Serial.available() > 0) {
    String _read = Serial.readStringUntil('\n');
    float coma = _read.indexOf(";");
    int _note = _read.substring(0, coma).toInt();
    int _time = _read.substring(coma+1, _read.length()).toInt();
    tone(falante, _note, _time);
  }
}
