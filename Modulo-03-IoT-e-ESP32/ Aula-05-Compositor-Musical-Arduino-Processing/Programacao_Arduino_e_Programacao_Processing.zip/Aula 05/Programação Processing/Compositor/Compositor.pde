import processing.serial.*;

Serial myPort;
int val;

FloatList notes, time;
PVector position;

PImage back;

Table table;
float getNote;
float getTime;

boolean interval=false;

void settings() {
  size(900, 600);
}

void setup() {
  notes = new FloatList();
  time = new FloatList();
  printArray(Serial.list());
  String portName = Serial.list()[1];
  myPort = new Serial(this, portName, 9600);
  position = new PVector();
  back = new PImage();
  back = loadImage("Back.png");
  table = loadTable("data.CSV", "header");
  println(table.getRowCount());
}

String combine(float _seek) {
  for (TableRow row : table.rows()) {
    float index = row.getFloat("INDEX");
    if (index==_seek) {
      String note = row.getString("LABEL");
      if (mousePressed) {
        getNote = row.getFloat("HZ");
        String send = Float.toString(getNote)+";"+"100";
        myPort.write(send);
        myPort.write('\n');
      }
      return note;
    }
  }
  return "";
}

void mousePressed() {
  getTime = millis();
}

void mouseReleased() {
  if (mapping>0 || interval) {
    notes.append(getNote);
    float now = millis() - getTime;
    time.append(now);
    interval=false;
  }
  println(notes.size());
  println(time.size());
}

void play() {
  for (int i=0; i<notes.size(); i++) {
    String _note = String.valueOf(notes.get(i));
    String _time = String.valueOf(time.get(i));
    int _delay = int(time.get(i));
    myPort.write(_note+";"+_time);
    myPort.write('\n');
    delay(_delay);
  }
}


int buttons() {
  String[] btLabel = {"CLEAN", "ERASE", "PLAY", "INTERVAL"};
  for (int i=0; i<4; i++) {
    float _color = 50+80*i;
    noStroke();
    float y = 110 + 60*i;

    fill(100);
    ellipse(780, y, 60, 60);

    float collision = dist(780, y, mouseX, mouseY);
    boolean test = (collision < 20) ? true : false;
    if (test) {
      fill(#16DEA3);
      if (mousePressed) {
        return i+1;
      }
    } else {
      fill(_color, 130, 200);
    }
    ellipse(780, y, 55, 50);
    fill(0);
    textSize(12);
    text(btLabel[i], 780, y);
  }
  return 0;
}

void decision(int j) {
  float _now = millis() - getTime;
  if (_now < 20) {
    switch (j) {
    case 1:
      time.clear();
      notes.clear();
      break;
    case 2:
      if (time.size() > 0 && mousePressed) {
        float indexTime = time.size();
        float indexNotes = notes.size();
        time.remove(time.size()-1);
        notes.remove(notes.size()-1);
        println("time "+indexTime);
        println("note "+indexNotes);
      }
      break;
    case 3:
      play();
      break;
    case 4:
      getNote = 0;
      interval=true;
      break;
    }
  }
}


void draw() {
  background(back);
  position.set(mouseX, mouseY);
  Guitar();
  String _label = combine(mapping);
  textAlign(CENTER, CENTER);
  fill(#5F595B);
  textSize(76);
  text("NOTE:", 150, 200);
  fill(255);
  textSize(72);
  text("NOTE:", 150, 200);
  fill(#5F595B);
  textSize(76);
  text(_label, 450, 200);
  fill(255);
  textSize(72);
  text(_label, 450, 200);
  decision(buttons());
} 
