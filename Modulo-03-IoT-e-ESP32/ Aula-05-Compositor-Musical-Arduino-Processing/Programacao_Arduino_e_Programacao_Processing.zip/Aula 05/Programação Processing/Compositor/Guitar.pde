String[] labels = {"MI","SI","SOL","RÉ","LÁ","MI"};
int[] prime = {3,5,7,11,13,17};
float mapping;

void Guitar(){
  //background(#52527a);
  mapping=0;
  fill(#825e17);
  stroke(#7E4600);
  strokeWeight(3);
  for(int i =0; i<13; i++){
    float _size = 715/13;
    boolean mouse = position.x > 90+(_size*i) && 
                    position.x < 90+(_size*i)+_size &&
                    position.y > 350 && position.y < 550;
    if(mouse){
      fill(#F02C2C);
      mapping = pow(2,i);
    }
    else{
      fill(#A7884E);
      if(Float.isNaN(mapping)){
        mapping=0;
      }
    }
    rect(90+(_size*i),350,_size,200);
  }
  for(int i=0;i<5;i++){
    fill(#7E4600);
    float position = 285+110*i;
    ellipse(position,450,15,15);
  }
  fill(#271F14);
  rect(90,350,60,200);
  for(int i =0; i<6; i++){
    boolean mouse = position.y > 340+(i*36) &&
                    position.y < 370+(i*36) &&
                    position.x > 90 &&
                    position.x < 805;
    float _y = 360+(i*36);
    if(mouse){
      fill(#F02C2C);
      ellipse(mouseX,_y,10,10);
      stroke(#22A217);
      mapping*=prime[i];
    }
    else{
      stroke(0);
    }
    line(90,_y,805,_y);
    fill(#F02C2C);
    ellipse(60,_y,30,30);
    textAlign(CENTER);
    fill(0);
    textSize(12);
    text(labels[i],60,_y+5);
  }
}
