import processing.serial.*; 
Serial myPort;    

String[] vetorRTC;
String inString;  

boolean testString;

int lf = 10;  
int cx, cy;

float secondsRadius;
float minutesRadius;
float hoursRadius;
float clockDiameter;

float s;
float m; 
float h;

float second;
float minute;
float hour;

void setup() {
  size(400, 400);
  stroke(255);
  
  myPort = new Serial(this, Serial.list()[1], 9600); 
  myPort.bufferUntil(lf);
  
  int radius = min(width, height) / 2;
  secondsRadius = radius * 0.72;
  minutesRadius = radius * 0.60;
  hoursRadius = radius * 0.50;
  clockDiameter = radius * 1.8;
  
  cx = width / 2;
  cy = height / 2;
}

void serialEvent(Serial p) { 
  inString = p.readString(); 
  
  vetorRTC = split(inString, ",");
  
  second = float(vetorRTC[2]);
  minute = float(vetorRTC[1]);
  hour = float(vetorRTC[0]);
  
  println(hour+":"+minute+":"+second);
  
  testString = p.active();
}

void draw() {
  if(testString){
    
    background(0);
    
    // background do relógio
    fill(5);
    noStroke();
    ellipse(cx, cy, clockDiameter, clockDiameter);
    
    s = map(second, 0, 60, 0, TWO_PI) - HALF_PI;
    m = map(minute + norm(second, 0, 60), 0, 60, 0, TWO_PI) - HALF_PI; 
    h = map(hour + norm(minute, 0, 60), 0, 24, 0, TWO_PI * 2) - HALF_PI;
    
    // ponteiros do relógio
    stroke(255);
    strokeWeight(1);
    line(cx, cy, cx + cos(s) * secondsRadius, cy + sin(s) * secondsRadius);
    strokeWeight(2);
    line(cx, cy, cx + cos(m) * minutesRadius, cy + sin(m) * minutesRadius);
    strokeWeight(4);
    line(cx, cy, cx + cos(h) * hoursRadius, cy + sin(h) * hoursRadius);
    
    // pontos de segundos
    strokeWeight(2);
    beginShape(POINTS);
    for (int a = 0; a < 360; a+=6) {
      float angle = radians(a);
      float x = cx + cos(angle) * secondsRadius;
      float y = cy + sin(angle) * secondsRadius;
      vertex(x, y);
    }
    endShape();
  }
}
