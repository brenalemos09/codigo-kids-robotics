#include <virtuabotixRTC.h>           

//myRTC(clock, data, rst)
virtuabotixRTC myRTC(5, 4, 2);

void setup()  
{      
  Serial.begin(9600);
  
  //(segundos, minutos, hora, dia da semana, dia do mes, mes, ano)
  myRTC.setDS1302Time(00, 41, 14, 4, 29, 9, 2030);
}
void loop()  
{
  //Le as informacoes do CI
  myRTC.updateTime(); 

  //String com os dados de data/hora
  Serial.flush();
  
  String ledPin = {(String)myRTC.hours+ "," +
                   (String)myRTC.minutes+ "," +
                   (String)myRTC.seconds};

  Serial.println(ledPin);
  delay(1000);
}
