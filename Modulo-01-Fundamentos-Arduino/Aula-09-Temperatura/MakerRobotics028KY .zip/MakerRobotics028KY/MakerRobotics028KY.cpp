#include "MakerRobotics028KY.h"
#include <math.h>
int pinoSensor_;
float variavelSensor_;
float CalcTemp;
float Tensao_;	


Temperatura::Temperatura(int pinoSensor){
pinoSensor_ = pinoSensor;
pinMode(pinoSensor_, INPUT);
}

float Temperatura::CalcularTemperatura(void){
variavelSensor_ = analogRead(pinoSensor_);
Tensao_ = (variavelSensor_)*(5.0/1024.0);
CalcTemp = log(10000*(5.0/Tensao_ - 1));
CalcTemp = 1 / (0.001129148 + (0.000234125 + (0.0000000876741 * CalcTemp * CalcTemp ))* CalcTemp );
CalcTemp = 273.15 - CalcTemp;
return CalcTemp;	
}

