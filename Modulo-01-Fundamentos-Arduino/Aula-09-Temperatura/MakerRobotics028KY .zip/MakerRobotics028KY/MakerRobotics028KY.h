#ifndef MakerRobotics028KY_H
#define MakerRobotics028KY_H
#include <Arduino.h>


class Temperatura{
			public:
				Temperatura(int pinoSensor);
				float CalcularTemperatura(void); 
				float CalcTemp;
			private:
				int pinoSensor_;
				float variavelSensor_;
				float Tensao_;
				
};
#endif


